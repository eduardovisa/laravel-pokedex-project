Mostrar la lista de pokemones
<?php /**PATH C:\xampp\htdocs\pokedex\resources\views/pokedex/index.blade.php ENDPATH**/ ?>