Envío de datos
<?php /**PATH C:\xampp\htdocs\pokedex\resources\views/pokedex/create.blade.php ENDPATH**/ ?>